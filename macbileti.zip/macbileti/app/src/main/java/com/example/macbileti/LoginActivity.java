package com.example.macbileti;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText etUser, etPass;
    DBHelper db;
    SharedPrefManager sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUser = findViewById(R.id.etUser);
        etPass = findViewById(R.id.etPass);

        db = new DBHelper(this);
        sp = new SharedPrefManager(this);
    }

    public void login(View v) {
        Cursor c = db.login(
                etUser.getText().toString(),
                etPass.getText().toString()
        );

        if (c.moveToFirst()) {
            sp.login(etUser.getText().toString());
            startActivity(new Intent(this, MatchListActivity.class));
            finish();
        } else {
            Toast.makeText(this, "Sisteme Kayıt Olunuz", Toast.LENGTH_SHORT).show();
        }
        c.close();
    }

    public void register(View v) {
        if (db.register(
                etUser.getText().toString(),
                etPass.getText().toString())) {
            Toast.makeText(this, "Kayıt başarılı", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Kullanıcı var", Toast.LENGTH_SHORT).show();
        }
    }
}
