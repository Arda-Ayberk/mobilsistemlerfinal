package com.example.macbileti;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PaymentActivity extends AppCompatActivity {

    EditText etCardNo, etExpiry, etCvv;
    Button btnPay;
    DBHelper db;
    SharedPrefManager sp;
    int seatId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        etCardNo = findViewById(R.id.etCardNo);
        etExpiry = findViewById(R.id.etExpiry);
        etCvv = findViewById(R.id.etCvv);
        btnPay = findViewById(R.id.btnPay);

        db = new DBHelper(this);
        sp = new SharedPrefManager(this);
        seatId = getIntent().getIntExtra("seatId", -1);

        btnPay.setOnClickListener(this::pay);
    }

    public void pay(View v) {
        String cardNo = etCardNo.getText().toString().trim();
        String expiry = etExpiry.getText().toString().trim();
        String cvv = etCvv.getText().toString().trim();

        if (cardNo.length() != 16) {
            Toast.makeText(this,"Kart numarası 16 haneli olmalıdır",Toast.LENGTH_SHORT).show();
            return;
        }
        if (cvv.length() != 3) {
            Toast.makeText(this,"CVV 3 haneli olmalıdır",Toast.LENGTH_SHORT).show();
            return;
        }
        if (expiry.isEmpty()) {
            Toast.makeText(this,"Son kullanma tarihi giriniz",Toast.LENGTH_SHORT).show();
            return;
        }

        db.buySeat(seatId, sp.getUser());

        Toast.makeText(this,"Ödeme başarılı, biletiniz alınmıştır",Toast.LENGTH_LONG).show();
        finish();
    }
}
