package com.example.macbileti;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class CategoryActivity extends AppCompatActivity {

    Spinner sp;
    int matchId;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_category);

        sp = findViewById(R.id.spCategory);
        matchId = getIntent().getIntExtra("matchId", -1);

        sp.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"VIP-1000 TL", "Maraton-800 tl", "Kale Arkası-500 TL", "Misafir-300 TL"}
        ));
    }

    public void goSeats(View v) {
        Intent it = new Intent(this, SeatActivity.class);
        it.putExtra("matchId", matchId);
        it.putExtra("category", sp.getSelectedItem().toString());
        startActivity(it);
    }
}
