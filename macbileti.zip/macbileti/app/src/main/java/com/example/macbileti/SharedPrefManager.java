package com.example.macbileti;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefManager {

    private static final String PREF = "session";
    private static final String KEY_LOGIN = "login";
    private static final String KEY_USER = "user";

    SharedPreferences sp;
    SharedPreferences.Editor ed;

    public SharedPrefManager(Context c) {
        sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        ed = sp.edit();
    }

    public void login(String user) {
        ed.putBoolean(KEY_LOGIN, true);
        ed.putString(KEY_USER, user);
        ed.apply();
    }

    public boolean isLoggedIn() {
        return sp.getBoolean(KEY_LOGIN, false);
    }

    public String getUser() {
        return sp.getString(KEY_USER, "");
    }

    public void logout() {
        ed.clear().apply();
    }
}
