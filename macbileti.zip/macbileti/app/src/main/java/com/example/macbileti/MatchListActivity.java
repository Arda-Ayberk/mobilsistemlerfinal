package com.example.macbileti;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MatchListActivity extends AppCompatActivity {

    SharedPrefManager sp;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_match_list);

        sp = new SharedPrefManager(this);

        ListView lvMatches = findViewById(R.id.listView);
        ListView lvTickets = findViewById(R.id.listViewTickets);
        Button btnLogout = findViewById(R.id.btnLogout);

        DBHelper db = new DBHelper(this);

        ArrayList<String> tickets = new ArrayList<>();
        Cursor ct = db.getMyTickets(sp.getUser());
        while (ct.moveToNext()) {
            tickets.add(
                    ct.getString(0) + " - " + ct.getString(1) +
                            " (" + ct.getString(2) + ")\n" +
                            "Kategori: " + ct.getString(3) +
                            " | Koltuk: " + ct.getInt(4)
            );
        }
        ct.close();

        lvTickets.setAdapter(new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, tickets));
        ArrayList<String> list = new ArrayList<>();
        ArrayList<Integer> ids = new ArrayList<>();

        Cursor c = db.getMatches();
        while (c.moveToNext()) {
            ids.add(c.getInt(0));
            list.add(c.getString(1) + " - " + c.getString(2));
        }
        c.close();

        lvMatches.setAdapter(new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, list));

        lvMatches.setOnItemClickListener((a, v, i, l) -> {
            Intent it = new Intent(this, CategoryActivity.class);
            it.putExtra("matchId", ids.get(i));
            startActivity(it);
        });

        btnLogout.setOnClickListener(v -> {
            sp.logout();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }
}
