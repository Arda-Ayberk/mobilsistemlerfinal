package com.example.macbileti;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context c) {
        super(c, "mac.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE users(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "username TEXT UNIQUE," +
                "password TEXT)");

        db.execSQL("CREATE TABLE matches(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "home TEXT," +
                "away TEXT," +
                "date TEXT)");

        db.execSQL("CREATE TABLE seats(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "match_id INTEGER," +
                "category TEXT," +
                "seat_no INTEGER," +
                "status INTEGER," +
                "username TEXT)");

        db.execSQL(
                "INSERT INTO matches(home,away,date) VALUES" +
                        "('Altay','Karşıyaka','12.01.2026')," +
                        "('Bucaspor 1928','MenemenFK','13.01.2026')," +
                        "('Sakaryaspor','Kocaelispor','14.01.2026')," +
                        "('Balıkesirspor','Bandırmaspor','15.01.2026')," +
                        "('Manisaspor','UşakFK','16.01.2026')," +
                        "('Denizlispor','Aydın','17.01.2026')," +
                        "('Turgutluspor','Akhisarspor','18.01.2026')"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int o, int n) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS matches");
        db.execSQL("DROP TABLE IF EXISTS seats");
        onCreate(db);
    }

    public boolean register(String u, String p) {
        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.rawQuery(
                "SELECT * FROM users WHERE username=?",
                new String[]{u});
        if (c.moveToFirst()) {
            c.close();
            return false;
        }
        c.close();
        db.execSQL("INSERT INTO users(username,password) VALUES(?,?)",
                new Object[]{u, p});
        return true;
    }

    public Cursor login(String u, String p) {
        return getReadableDatabase().rawQuery(
                "SELECT * FROM users WHERE username=? AND password=?",
                new String[]{u, p});
    }

    public Cursor getMatches() {
        return getReadableDatabase()
                .rawQuery("SELECT * FROM matches", null);
    }

    public void createSeats(int matchId, String cat) {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT * FROM seats WHERE match_id=? AND category=?",
                new String[]{String.valueOf(matchId), cat});
        if (c.getCount() == 0) {
            for (int i = 1; i <= 50; i++) {
                getWritableDatabase().execSQL(
                        "INSERT INTO seats(match_id,category,seat_no,status) VALUES(?,?,?,0)",
                        new Object[]{matchId, cat, i});
            }
        }
        c.close();
    }

    public Cursor getSeats(int matchId, String cat) {
        return getReadableDatabase().rawQuery(
                "SELECT * FROM seats WHERE match_id=? AND category=?",
                new String[]{String.valueOf(matchId), cat});
    }

    public void buySeat(int seatId, String username) {
        getWritableDatabase().execSQL(
                "UPDATE seats SET status=1, username=? WHERE id=?",
                new Object[]{username, seatId});
    }

    public Cursor getMyTickets(String user) {
        return getReadableDatabase().rawQuery(
                "SELECT m.home, m.away, m.date, s.category, s.seat_no " +
                        "FROM seats s JOIN matches m ON m.id=s.match_id " +
                        "WHERE s.username=?",
                new String[]{user});
    }
}
