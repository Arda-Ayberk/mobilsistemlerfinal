package com.example.macbileti;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class SeatActivity extends AppCompatActivity {

    GridLayout grid;
    Button btnContinue;
    DBHelper db;

    int matchId;
    String category;
    int selectedSeatId = -1;
    Button selectedBtn = null;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_seat);

        grid = findViewById(R.id.gridSeats);
        btnContinue = findViewById(R.id.btnContinue);
        btnContinue.setEnabled(false);

        db = new DBHelper(this);

        matchId = getIntent().getIntExtra("matchId", -1);
        category = getIntent().getStringExtra("category");

        db.createSeats(matchId, category);
        loadSeats();

        btnContinue.setOnClickListener(v -> {
            Intent it = new Intent(this, PaymentActivity.class);
            it.putExtra("seatId", selectedSeatId);
            startActivity(it);
        });
    }

    void loadSeats() {
        Cursor c = db.getSeats(matchId, category);
        int index = 0;

        while (c.moveToNext()) {
            int seatId = c.getInt(0);
            int seatNo = c.getInt(3);
            int status = c.getInt(4);

            Button btn = new Button(this);
            btn.setText(String.valueOf(seatNo));

            GridLayout.LayoutParams p = new GridLayout.LayoutParams();
            p.width = 0;
            p.columnSpec = GridLayout.spec(index % 5, 1f);
            btn.setLayoutParams(p);

            if (status == 1) {
                btn.setEnabled(false);
                btn.setBackgroundColor(Color.BLACK);
            } else {
                btn.setBackgroundColor(Color.GREEN);
                btn.setOnClickListener(v -> {
                    if (selectedBtn != null)
                        selectedBtn.setBackgroundColor(Color.GREEN);
                    selectedSeatId = seatId;
                    selectedBtn = btn;
                    btn.setBackgroundColor(Color.BLUE);
                    btnContinue.setEnabled(true);
                });
            }
            grid.addView(btn);
            index++;
        }
        c.close();
    }
}
